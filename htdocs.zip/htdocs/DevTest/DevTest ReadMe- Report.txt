Coding Tools Used:
__________________
I have written the program in Javascript, with a D3.js library import.
I am most comfortable dealing with data manipulation and visualization with these tools.
Additionally, it required an XAMPP Apache local web-server to run.

Issues:
_______
The first hiccup I hit was that Javascript does not allow writing to files.
I am aware that niche editors with plugins exist to achieve this, but I'm almost at the time limit.
Using a server side language would overcome this easily.

The second was rounding averages to a single decimal.
It has been a year since I last used d3, and in that time, the d3.round() function had been deprecated.
I knew there had to be a workaround with Math.round() but simply couldn't figure it out myself.
I finally managed to find the rather cumbersome implementation on a community forum.

Seeing as I could not write to files, I copied the entire output from the Dev Console in Chrome and pasted it in a txt for your perusal.

Potential Code Failure:
_______________________
csv isn't the most standardised format for datasets.
A simple blank space in the dataset column names require special care while accessing them within code.

Try-Catch blocks could be implemented right at the part where the 'Floor' function is performed.
This would ensure that a stray string does not compromise its integrity.
Javascript is a language with very flexible variable types.
Had this been another language, I would have had to be more careful performing conversion, rounding and truncating to avoid losing data beyond the decimal.
Accidental negative values pose more of a threat since they might not throw any errors while being lumped with other sums for totals.
The only solution to this would be to manually identify big discrepancies and make sure if it is caused by faulty input or simply vast performance differences.

File I/O is another concern while using other languages.
Assuming there are students with accent in their names, it would make it through the program file since there are no specific string operations.
Still, while writing into a txt or bin file there is a chance it appears as an un-identified character.
If we were to use this file as input for another file it could wreck havoc.

Additional Instruction to run code:
___________________________________
place the htdocs folder as-is in the 'htdocs' folder in root directory of xampp, accept all merges.
After starting apache server on xampp, navigate within localhost:portnumber in your browser to the DevTest.html